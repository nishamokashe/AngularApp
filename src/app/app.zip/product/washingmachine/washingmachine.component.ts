import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-washingmachine',
  templateUrl: './washingmachine.component.html',
  styleUrls: ['./washingmachine.component.css']
})
export class WashingmachineComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
