export class Post{
    useerId:number;
    id:number;
    title:string;
    body:string;
}