import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-form-assignment',
  templateUrl: './form-assignment.component.html',
  styleUrls: ['./form-assignment.component.css']
})
export class FormAssignmentComponent implements OnInit {
  username = '';
  defaultCourseValue = 'JavaScript';
  constructor() { }

  ngOnInit() {
  }

}
